#include <iostream>
#include <random>
#include <chrono>
#include "TrafficLight.h"

/* Implementation of class "MessageQueue" */
template <typename T>
T MessageQueue<T>::receive()
{
   
    std::unique_lock<std::mutex> lck(_mtxMQ);//The method receive use std::unique_lock<std::mutex>
    _condition.wait(lck, [this] { return !_queue.empty(); });
    T lightPhase = std::move(_queue.back());// to wait for and receive new messages and pull them from the queue using move semantics. 
    _queue.pop_back();// remove the last element from the _queue
    return lightPhase;// The received object should then be returned by the receive function.
}

template <typename T>
void MessageQueue<T>::send(T &&msg)
{
    std::lock_guard<std::mutex> lck(_mtxMQ);
    _queue.emplace_front(std::move(msg));// move the massage queue
    // _queue should only contain one element, so push out the last element
    if (_queue.size() != 1)
        _queue.pop_back();// remove the last element from the massage queue
    _condition.notify_one();
}

void TrafficLight::waitForGreen()
{
 
    while (true)
    {
        if (_messageQ.receive() == TrafficLightPhase::green)
            return;
    }
}

TrafficLightPhase TrafficLight::getCurrentPhase()
{
    return _currentPhase;
}

void TrafficLight::simulate()
{
    threads.emplace_back(std::thread(&TrafficLight::cycleThroughPhases, this));
}
	
double RandomWaitTime()
{
  	
    /*
    References:
    https://en.cppreference.com/w/cpp/chrono/high_resolution_clock
    https://en.cppreference.com/w/cpp/chrono/time_point
    */
    typedef std::chrono::high_resolution_clock setclock;
    setclock::time_point atBeginning = setclock::now();

    // obtain a interval_count from the timer
    setclock::duration d = setclock::now() - atBeginning;
    unsigned inteval_count = d.count();

    std::mt19937 generate(inteval_count);
    std::uniform_real_distribution<double> distribution(4, 6);//set ramdom between 4 seconds to 6seconds.
    return distribution(generate) * 1000;//return in second.
}


void TrafficLight::cycleThroughPhases()
{
    int cycleDuration = RandomWaitTime();
    std::chrono::time_point<std::chrono::system_clock> lastUpdate;
    lastUpdate = std::chrono::system_clock::now();

    while (true)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));

        // compute time difference to stop watch
        long timeSinceLastUpdate = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() - lastUpdate).count();
        if (timeSinceLastUpdate >= cycleDuration)
        {
            cycleDuration = RandomWaitTime(); // reset light duration
            switch (_currentPhase)
            {
            case TrafficLightPhase::green:
                _currentPhase = TrafficLightPhase::red;
                break;
            case TrafficLightPhase::red:
                _currentPhase = TrafficLightPhase::green;
                break;
            }

            _messageQ.send(std::move(_currentPhase));
            lastUpdate = std::chrono::system_clock::now();
        }
    }
}
